# Chronos-Nuker
[Discord](https://dsc.gg/akago)

## _Open Source Discord Account Nuker_
This nuker abuses the discord api to mess with user accounts.

## ⚙️ Installation
- Install python from [here](https://www.python.org/)
- Double click the [start.bat file](./start.bat)

## 🖼️ Preview

![](./images/terminal.png)

## ☕️ Socials
[![TikTok Link](https://img.shields.io/badge/TikTok-000000?style=for-the-badge&logo=tiktok&logoColor=white)](https://tiktok.com/@maxii.x6)
[![Twitter Link](https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/gokimax_x)
[![Insta Link](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/maxii.x6)
